package kr.pataidcompany.patent_backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class SchedulingConfig {
    // 이 클래스 내부에 아무 내용이 없어도 됨
}
